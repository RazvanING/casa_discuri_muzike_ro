<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `phpmuzike`
 */

/* `phpmuzike`.`admin_panel` */
$admin_panel = array(
  array('id' => '34','datetime' => '17-01-2025 19:48:22','title' => 'Anomalia','category' => 'Thrash Metal','author' => 'Razvan','image' => 'https---images.genius.com-3316dc684f27001692b85048434024f2.600x600x1.jpg','sample' => '12. Anomalia.mp3','post' => 'Anomalos')
);

/* `phpmuzike`.`category` */
$category = array(
  array('id' => '2','datetime' => '16-01-2025 21:02:00','name' => 'Metal','createdby' => 'Razvan'),
  array('id' => '3','datetime' => '16-01-2025 21:03:05','name' => 'Rock','createdby' => 'Razvan'),
  array('id' => '4','datetime' => '16-01-2025 21:07:29','name' => 'Pop','createdby' => 'Razvan'),
  array('id' => '6','datetime' => '16-01-2025 21:34:42','name' => 'Thrash Metal','createdby' => 'Razvan'),
  array('id' => '7','datetime' => '16-01-2025 21:39:25','name' => 'Ethno','createdby' => 'Razvan')
);

/* `phpmuzike`.`comments` */
$comments = array(
  array('id' => '3','datetime' => '17-01-2025 20:30:19','name' => 'test','email' => 'test@test.ro','comment' => 'test','status' => 'OFF','admin_panel_id' => '34'),
  array('id' => '4','datetime' => '17-01-2025 20:38:52','name' => 'test','email' => 'test@test.rp','comment' => 'test','status' => 'OFF','admin_panel_id' => '34'),
  array('id' => '5','datetime' => '17-01-2025 21:26:18','name' => 'pop','email' => 'pop@pop.rp','comment' => 'pop','status' => 'ON','admin_panel_id' => '34')
);

/* `phpmuzike`.`registration` */
$registration = array(
  array('id' => '1','datetime' => '17-01-2025 23:02:46','addedby' => 'Razvan','username' => 'Razvan','password' => 'lambda2006'),
  array('id' => '2','datetime' => '17-01-2025 23:03:08','addedby' => 'Razvan','username' => 'VSL','password' => '1234567890')
);
